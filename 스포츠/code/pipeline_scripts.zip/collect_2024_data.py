"""
2024 시즌 F1 데이터 수집 스크립트
- 페널티, 추월/방어 제외
- 평가 영역: 속도(롱런/숏런), 일관성, 타이어 관리, 주행 안정성
"""
import fastf1
import pandas as pd
import numpy as np
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# ============================================
# 설정
# ============================================
YEAR = 2024
CACHE_DIR = Path("./cache")
OUTPUT_DIR = Path("./data")

CACHE_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
fastf1.Cache.enable_cache(str(CACHE_DIR))


def get_schedule(year: int) -> pd.DataFrame:
    """시즌 일정 가져오기"""
    schedule = fastf1.get_event_schedule(year)
    # 테스트 제외, 실제 레이스만
    schedule = schedule[schedule['EventFormat'] != 'testing']
    return schedule


def collect_race_laps(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    레이스 랩 데이터 수집
    - 롱런 페이스, 타이어 관리, 주행 안정성용
    """
    try:
        session = fastf1.get_session(year, round_num, 'R')
        session.load()
        
        laps = session.laps[[
            'Driver', 'DriverNumber', 'Team',
            'LapNumber', 'LapTime', 'Time',
            'Stint', 'Compound', 'TyreLife', 'FreshTyre',
            'Sector1Time', 'Sector2Time', 'Sector3Time',
            'SpeedI1', 'SpeedI2', 'SpeedFL', 'SpeedST',
            'PitInTime', 'PitOutTime',
            'IsPersonalBest', 'IsAccurate', 'Deleted'
        ]].copy()
        
        laps['Year'] = year
        laps['Round'] = round_num
        laps['EventName'] = event_name
        
        # LapTime을 초 단위로 변환
        laps['LapTimeSeconds'] = laps['LapTime'].dt.total_seconds()
        laps['Sector1Seconds'] = laps['Sector1Time'].dt.total_seconds()
        laps['Sector2Seconds'] = laps['Sector2Time'].dt.total_seconds()
        laps['Sector3Seconds'] = laps['Sector3Time'].dt.total_seconds()
        
        return laps
    
    except Exception as e:
        print(f"    ⚠️ 레이스 랩 수집 실패: {e}")
        return pd.DataFrame()


def collect_qualifying_results(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    예선 결과 수집
    - 숏런 페이스용 (Q1, Q2, Q3 랩타임)
    """
    try:
        session = fastf1.get_session(year, round_num, 'Q')
        session.load()
        
        results = session.results[[
            'DriverNumber', 'Abbreviation', 'FullName',
            'TeamName', 'TeamColor',
            'Position', 'Q1', 'Q2', 'Q3'
        ]].copy()
        
        results['Year'] = year
        results['Round'] = round_num
        results['EventName'] = event_name
        
        # Q1, Q2, Q3를 초 단위로 변환
        results['Q1Seconds'] = results['Q1'].dt.total_seconds()
        results['Q2Seconds'] = results['Q2'].dt.total_seconds()
        results['Q3Seconds'] = results['Q3'].dt.total_seconds()
        
        return results
    
    except Exception as e:
        print(f"    ⚠️ 예선 결과 수집 실패: {e}")
        return pd.DataFrame()


def collect_race_results(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    레이스 결과 수집
    - 일관성, 주행 안정성용 (순위, DNF 상태)
    """
    try:
        session = fastf1.get_session(year, round_num, 'R')
        session.load()
        
        results = session.results[[
            'DriverNumber', 'Abbreviation', 'FullName',
            'TeamName', 'TeamColor',
            'Position', 'ClassifiedPosition', 'GridPosition',
            'Status', 'Points', 'Time'
        ]].copy()
        
        results['Year'] = year
        results['Round'] = round_num
        results['EventName'] = event_name
        
        # DNF 여부 판단
        results['IsDNF'] = ~results['Status'].isin(['Finished', '+1 Lap', '+2 Laps', '+3 Laps'])
        
        # DNF 유형 분류
        def classify_dnf(status):
            if status in ['Finished', '+1 Lap', '+2 Laps', '+3 Laps']:
                return 'Finished'
            elif 'Collision' in str(status) or 'Accident' in str(status) or 'Crash' in str(status):
                return 'Accident'
            elif 'Engine' in str(status) or 'Power' in str(status) or 'Hydraulics' in str(status):
                return 'Mechanical'
            elif 'Gearbox' in str(status) or 'Transmission' in str(status):
                return 'Mechanical'
            elif 'Spin' in str(status):
                return 'Driver_Error'
            else:
                return 'Other'
        
        results['DNFType'] = results['Status'].apply(classify_dnf)
        
        return results
    
    except Exception as e:
        print(f"    ⚠️ 레이스 결과 수집 실패: {e}")
        return pd.DataFrame()


def collect_weather_data(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    날씨 데이터 수집 (레이스 세션)
    """
    try:
        session = fastf1.get_session(year, round_num, 'R')
        session.load()
        
        weather = session.weather_data.copy()
        weather['Year'] = year
        weather['Round'] = round_num
        weather['EventName'] = event_name
        
        return weather
    
    except Exception as e:
        print(f"    ⚠️ 날씨 데이터 수집 실패: {e}")
        return pd.DataFrame()


def main():
    print("=" * 70)
    print(f"🏎️  {YEAR} 시즌 F1 데이터 수집 시작")
    print("=" * 70)
    
    # 시즌 일정 가져오기
    schedule = get_schedule(YEAR)
    print(f"\n📅 {YEAR} 시즌 총 {len(schedule)}개 이벤트\n")
    
    # 데이터 저장용 리스트
    all_race_laps = []
    all_quali_results = []
    all_race_results = []
    all_weather = []
    
    # 각 라운드별 데이터 수집
    for idx, event in schedule.iterrows():
        round_num = event['RoundNumber']
        event_name = event['EventName']
        
        print(f"[Round {round_num:02d}] {event_name}")
        
        # 1. 레이스 랩 데이터
        print("    📊 레이스 랩 데이터 수집 중...")
        race_laps = collect_race_laps(YEAR, round_num, event_name)
        if not race_laps.empty:
            all_race_laps.append(race_laps)
            print(f"       ✓ {len(race_laps)} 랩 수집 완료")
        
        # 2. 예선 결과
        print("    🏁 예선 결과 수집 중...")
        quali_results = collect_qualifying_results(YEAR, round_num, event_name)
        if not quali_results.empty:
            all_quali_results.append(quali_results)
            print(f"       ✓ {len(quali_results)} 드라이버 수집 완료")
        
        # 3. 레이스 결과
        print("    🏆 레이스 결과 수집 중...")
        race_results = collect_race_results(YEAR, round_num, event_name)
        if not race_results.empty:
            all_race_results.append(race_results)
            print(f"       ✓ {len(race_results)} 드라이버 수집 완료")
        
        # 4. 날씨 데이터
        print("    🌤️  날씨 데이터 수집 중...")
        weather = collect_weather_data(YEAR, round_num, event_name)
        if not weather.empty:
            all_weather.append(weather)
            print(f"       ✓ {len(weather)} 레코드 수집 완료")
        
        print()
    
    # 데이터 병합 및 저장
    print("=" * 70)
    print("💾 데이터 저장 중...")
    print("=" * 70)
    
    # 레이스 랩 데이터
    if all_race_laps:
        df_race_laps = pd.concat(all_race_laps, ignore_index=True)
        df_race_laps.to_csv(OUTPUT_DIR / 'race_laps_2024.csv', index=False)
        df_race_laps.to_parquet(OUTPUT_DIR / 'race_laps_2024.parquet', index=False)
        print(f"✅ race_laps_2024: {len(df_race_laps)} rows")
    
    # 예선 결과
    if all_quali_results:
        df_quali = pd.concat(all_quali_results, ignore_index=True)
        df_quali.to_csv(OUTPUT_DIR / 'qualifying_results_2024.csv', index=False)
        df_quali.to_parquet(OUTPUT_DIR / 'qualifying_results_2024.parquet', index=False)
        print(f"✅ qualifying_results_2024: {len(df_quali)} rows")
    
    # 레이스 결과
    if all_race_results:
        df_race_results = pd.concat(all_race_results, ignore_index=True)
        df_race_results.to_csv(OUTPUT_DIR / 'race_results_2024.csv', index=False)
        df_race_results.to_parquet(OUTPUT_DIR / 'race_results_2024.parquet', index=False)
        print(f"✅ race_results_2024: {len(df_race_results)} rows")
    
    # 날씨 데이터
    if all_weather:
        df_weather = pd.concat(all_weather, ignore_index=True)
        df_weather.to_csv(OUTPUT_DIR / 'weather_2024.csv', index=False)
        df_weather.to_parquet(OUTPUT_DIR / 'weather_2024.parquet', index=False)
        print(f"✅ weather_2024: {len(df_weather)} rows")
    
    # 시즌 일정 저장
    schedule.to_csv(OUTPUT_DIR / 'schedule_2024.csv', index=False)
    print(f"✅ schedule_2024: {len(schedule)} rows")
    
    print("\n" + "=" * 70)
    print("🏁 데이터 수집 완료!")
    print("=" * 70)
    
    # 수집된 데이터 요약
    print("\n📋 수집된 데이터 요약:")
    print(f"   - 레이스 랩: {len(df_race_laps) if all_race_laps else 0} rows")
    print(f"   - 예선 결과: {len(df_quali) if all_quali_results else 0} rows")
    print(f"   - 레이스 결과: {len(df_race_results) if all_race_results else 0} rows")
    print(f"   - 날씨 데이터: {len(df_weather) if all_weather else 0} rows")
    print(f"\n📁 저장 위치: {OUTPUT_DIR.absolute()}")


if __name__ == "__main__":
    main()



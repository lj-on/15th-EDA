"""
F1 Data Collection Script (2024)
- Raw data collection from FastF1
- Shared keys for table merging: Year, Round, EventName, Driver, DriverNumber
- DNF classification included
"""
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

import fastf1
import pandas as pd
from pathlib import Path
import warnings
import time
warnings.filterwarnings('ignore')

# ============================================
# Configuration
# ============================================
START_YEAR = 2023
END_YEAR = 2023
CACHE_DIR = Path("./cache")
OUTPUT_DIR = Path("./data")

CACHE_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
fastf1.Cache.enable_cache(str(CACHE_DIR))


# ============================================
# DNF Classification
# ============================================
def classify_dnf(status: str) -> str:
    """Classify DNF type based on status text"""
    status = str(status)
    if status in ['Finished', '+1 Lap', '+2 Laps', '+3 Laps', '+4 Laps', '+5 Laps', '+6 Laps']:
        return 'Finished'
    elif any(kw in status for kw in ['Collision', 'Accident', 'Crash', 'Contact']):
        return 'Accident'
    elif any(kw in status for kw in ['Engine', 'Power', 'Hydraulics', 'Gearbox', 'Transmission', 'Brakes', 'ERS', 'MGU', 'Turbo', 'Oil', 'Water', 'Overheating']):
        return 'Mechanical'
    elif any(kw in status for kw in ['Spin', 'Off track', 'Driver error', 'Spun off']):
        return 'Driver_Error'
    else:
        return 'Other'


def is_dnf(status: str) -> bool:
    """Check if status is DNF"""
    return status not in ['Finished', '+1 Lap', '+2 Laps', '+3 Laps', '+4 Laps', '+5 Laps', '+6 Laps']


# ============================================
# Schedule (for round info only)
# ============================================
def get_schedule(year: int) -> pd.DataFrame:
    """Get season schedule"""
    schedule = fastf1.get_event_schedule(year)
    schedule = schedule[schedule['EventFormat'] != 'testing']
    return schedule


# ============================================
# Race Laps
# ============================================
def collect_race_laps(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    Collect race lap data
    Key columns: Year, Round, EventName, Driver, DriverNumber
    """
    try:
        session = fastf1.get_session(year, round_num, 'R')
        session.load()
        
        columns = [
            # Key columns
            'Driver', 'DriverNumber', 'Team',
            # Lap info
            'LapNumber', 'LapTime', 'Time', 'Position',
            # Stint/Tyre
            'Stint', 'Compound', 'TyreLife', 'FreshTyre',
            # Sector times
            'Sector1Time', 'Sector2Time', 'Sector3Time',
            'Sector1SessionTime', 'Sector2SessionTime', 'Sector3SessionTime',
            # Speed
            'SpeedI1', 'SpeedI2', 'SpeedFL', 'SpeedST',
            # Pit
            'PitInTime', 'PitOutTime',
            # Time info
            'LapStartTime', 'LapStartDate',
            # Status
            'TrackStatus', 'IsPersonalBest', 'IsAccurate', 'Deleted'
        ]
        
        available_cols = [c for c in columns if c in session.laps.columns]
        laps = session.laps[available_cols].copy()
        
        # Shared keys
        laps['Year'] = year
        laps['Round'] = round_num
        laps['EventName'] = event_name
        laps['TotalLaps'] = session.total_laps if hasattr(session, 'total_laps') else laps['LapNumber'].max()
        
        return laps
    
    except Exception as e:
        print(f"      [!] Race laps failed: {e}")
        return pd.DataFrame()




# ============================================
# Qualifying Results
# ============================================
def collect_qualifying_results(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    Collect qualifying results (Q1/Q2/Q3)
    Key columns: Year, Round, EventName, Driver (Abbreviation), DriverNumber
    """
    try:
        session = fastf1.get_session(year, round_num, 'Q')
        session.load()
        
        columns = [
            'DriverNumber', 'BroadcastName', 'Abbreviation', 'FullName',
            'TeamName', 'TeamColor', 'TeamId',
            'FirstName', 'LastName', 'CountryCode',
            'Position', 'Q1', 'Q2', 'Q3'
        ]
        
        available_cols = [c for c in columns if c in session.results.columns]
        results = session.results[available_cols].copy()
        
        # Shared keys
        results['Year'] = year
        results['Round'] = round_num
        results['EventName'] = event_name
        # Add Driver column for consistency
        if 'Abbreviation' in results.columns:
            results['Driver'] = results['Abbreviation']
        
        return results
    
    except Exception as e:
        print(f"      [!] Qualifying results failed: {e}")
        return pd.DataFrame()


# ============================================
# Qualifying Laps
# ============================================
def collect_qualifying_laps(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    Collect qualifying lap data (sector analysis)
    Key columns: Year, Round, EventName, Driver, DriverNumber
    """
    try:
        session = fastf1.get_session(year, round_num, 'Q')
        session.load()
        
        columns = [
            # Key columns
            'Driver', 'DriverNumber', 'Team',
            # Lap info
            'LapNumber', 'LapTime', 'Time',
            # Sector times
            'Sector1Time', 'Sector2Time', 'Sector3Time',
            'Sector1SessionTime', 'Sector2SessionTime', 'Sector3SessionTime',
            # Speed
            'SpeedI1', 'SpeedI2', 'SpeedFL', 'SpeedST',
            # Tyre
            'Compound', 'TyreLife',
            # Time info
            'LapStartTime', 'LapStartDate',
            # Status
            'IsPersonalBest', 'Deleted', 'IsAccurate'
        ]
        
        available_cols = [c for c in columns if c in session.laps.columns]
        laps = session.laps[available_cols].copy()
        
        # Shared keys
        laps['Year'] = year
        laps['Round'] = round_num
        laps['EventName'] = event_name
        
        return laps
    
    except Exception as e:
        print(f"      [!] Qualifying laps failed: {e}")
        return pd.DataFrame()


# ============================================
# Race Results
# ============================================
def collect_race_results(year: int, round_num: int, event_name: str) -> pd.DataFrame:
    """
    Collect race results (positions, DNF status)
    Key columns: Year, Round, EventName, Driver (Abbreviation), DriverNumber
    Includes: IsDNF, DNFType
    """
    try:
        session = fastf1.get_session(year, round_num, 'R')
        session.load()
        
        columns = [
            'DriverNumber', 'BroadcastName', 'Abbreviation', 'FullName',
            'TeamName', 'TeamColor', 'TeamId',
            'FirstName', 'LastName', 'CountryCode',
            'Position', 'ClassifiedPosition', 'GridPosition',
            'Status', 'Points', 'Time'
        ]
        
        available_cols = [c for c in columns if c in session.results.columns]
        results = session.results[available_cols].copy()
        
        # Shared keys
        results['Year'] = year
        results['Round'] = round_num
        results['EventName'] = event_name
        # Add Driver column for consistency
        if 'Abbreviation' in results.columns:
            results['Driver'] = results['Abbreviation']
        
        # DNF classification
        if 'Status' in results.columns:
            results['IsDNF'] = results['Status'].apply(is_dnf)
            results['DNFType'] = results['Status'].apply(classify_dnf)
        
        return results
    
    except Exception as e:
        print(f"      [!] Race results failed: {e}")
        return pd.DataFrame()


# ============================================
# Main
# ============================================
def main():
    print("=" * 70)
    print(f"[F1 Data Collection] {START_YEAR}-{END_YEAR}")
    print("=" * 70)
    print("\nShared Keys: Year, Round, EventName, Driver, DriverNumber")
    print("Tables: race_laps, qualifying_laps, qualifying_results, race_results\n")
    
    # Data containers
    all_race_laps = []
    all_quali_results = []
    all_quali_laps = []
    all_race_results = []
    
    # Collect by year
    for year in range(START_YEAR, END_YEAR + 1):
        print(f"\n{'='*70}")
        print(f"[{year} Season]")
        print("=" * 70)
        
        try:
            schedule = get_schedule(year)
            print(f"   Total {len(schedule)} events\n")
        except Exception as e:
            print(f"   [!] Failed to load {year} schedule: {e}")
            continue
        
        # Collect by round
        for idx, event in schedule.iterrows():
            round_num = event['RoundNumber']
            event_name = event['EventName']
            
            print(f"   [Round {round_num:02d}] {event_name}")
            
            # 1. Race Laps
            print("      > Race laps...")
            df = collect_race_laps(year, round_num, event_name)
            if not df.empty:
                all_race_laps.append(df)
                print(f"        OK: {len(df)} laps")
            
            # 2. Qualifying Results
            print("      > Qualifying results...")
            df = collect_qualifying_results(year, round_num, event_name)
            if not df.empty:
                all_quali_results.append(df)
                print(f"        OK: {len(df)} drivers")
            
            # 3. Qualifying Laps
            print("      > Qualifying laps...")
            df = collect_qualifying_laps(year, round_num, event_name)
            if not df.empty:
                all_quali_laps.append(df)
                print(f"        OK: {len(df)} laps")
            
            # 4. Race Results (with DNF)
            print("      > Race results...")
            df = collect_race_results(year, round_num, event_name)
            if not df.empty:
                all_race_results.append(df)
                print(f"        OK: {len(df)} drivers")
            
            print()
            time.sleep(0.3)
    
    # ============================================
    # Save Data
    # ============================================
    print("\n" + "=" * 70)
    print("[Saving Data]")
    print("=" * 70)
    
    datasets = [
        ('race_laps', all_race_laps),
        ('qualifying_results', all_quali_results),
        ('qualifying_laps', all_quali_laps),
        ('race_results', all_race_results),
    ]
    
    for name, data_list in datasets:
        if data_list:
            df = pd.concat(data_list, ignore_index=True)
            df.to_csv(OUTPUT_DIR / f'{name}.csv', index=False)
            print(f"[OK] {name}.csv: {len(df):,} rows")
    
    print("\n" + "=" * 70)
    print("[DONE] Data collection completed!")
    print(f"[PATH] {OUTPUT_DIR.absolute()}")
    print("=" * 70)
    
    # Print key columns info
    print("\n[Key Columns for Merging]")
    print("  - All tables: Year, Round, EventName")
    print("  - Lap tables: + Driver, DriverNumber")
    print("  - Result tables: + Driver (=Abbreviation), DriverNumber")
    print("  - race_results includes: IsDNF, DNFType")


if __name__ == "__main__":
    main()

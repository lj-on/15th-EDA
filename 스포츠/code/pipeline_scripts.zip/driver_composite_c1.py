# -*- coding: utf-8 -*-
"""
C 방법 1: 평균 잔차 기반 드라이버 종합 실력 점수.
- 전체 OLS 적합 → 드라이버별 평균 잔차 → 0~10 스케일 → 순위 부여.
- 출력: final_data/driver_composite_score_c1.csv (Driver, n_races, mean_residual, composite_score_0_10, rank)
"""

import pandas as pd
import numpy as np
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from regression_gp_final_position import (
    build_gp_level_df,
    PREDICTOR_COLS,
    CONFOUNDER_COLS,
)

try:
    import statsmodels.api as sm
except ImportError:
    sm = None

BASE_DIR = Path(__file__).resolve().parent
FINAL_DIR = BASE_DIR / "final_data"
OUT_CSV = FINAL_DIR / "driver_composite_score_c1.csv"


def main():
    if sm is None:
        raise ImportError("statsmodels 필요: pip install statsmodels")

    gp = build_gp_level_df()
    y_col = "rank_value"
    X_cols = PREDICTOR_COLS + CONFOUNDER_COLS
    all_cols = [y_col] + X_cols + ["Driver"]
    use = gp[all_cols].dropna(how="any")

    X = use[X_cols]
    y = use[y_col]
    X_const = sm.add_constant(X, has_constant="add")
    model = sm.OLS(y, X_const).fit()

    use = use.copy()
    use["resid"] = model.resid.values

    agg = use.groupby("Driver").agg(
        mean_residual=("resid", "mean"),
        n_races=("resid", "size"),
    ).reset_index()

    # n_races > 24 인 드라이버만 평가대상 (방법론 §5)
    agg = agg[agg["n_races"] > 24].copy().reset_index(drop=True)
    mr = agg["mean_residual"]
    lo, hi = mr.min(), mr.max()
    if hi > lo:
        agg["composite_score_0_10"] = 10.0 * (mr - lo) / (hi - lo)
    else:
        agg["composite_score_0_10"] = 5.0

    agg["rank"] = agg["mean_residual"].rank(ascending=False, method="min").astype(int)
    agg = agg.sort_values("rank").reset_index(drop=True)

    agg = agg[["Driver", "n_races", "mean_residual", "composite_score_0_10", "rank"]]
    agg.to_csv(OUT_CSV, index=False)
    print(f"저장: {OUT_CSV}")
    print(f"드라이버 수: {len(agg)}, 회귀 관측 수: {len(use)}")
    print("\n상위 15 (종합 실력 순위):")
    print(agg.head(15).to_string(index=False))
    print("\n하위 10:")
    print(agg.tail(10).to_string(index=False))


if __name__ == "__main__":
    main()

"""
FastF1을 사용한 F1 데이터 수집 스크립트
"""
import fastf1
import pandas as pd
from pathlib import Path

# 캐시 디렉토리 설정 (데이터 재다운로드 방지)
CACHE_DIR = Path("./cache")
CACHE_DIR.mkdir(exist_ok=True)
fastf1.Cache.enable_cache(str(CACHE_DIR))


def get_session_data(year: int, grand_prix: str, session_type: str = "R") -> fastf1.core.Session:
    """
    특정 세션 데이터를 로드합니다.
    
    Args:
        year: 시즌 연도 (예: 2024)
        grand_prix: 그랑프리 이름 또는 번호 (예: "Monaco", "Bahrain", 1)
        session_type: 세션 타입
            - "FP1", "FP2", "FP3": 프리 프랙티스
            - "Q": 예선
            - "S": 스프린트
            - "SQ": 스프린트 예선
            - "R": 레이스
    
    Returns:
        fastf1 Session 객체
    """
    session = fastf1.get_session(year, grand_prix, session_type)
    session.load()
    return session


def get_lap_times(session: fastf1.core.Session) -> pd.DataFrame:
    """
    세션의 모든 랩 타임 데이터를 가져옵니다.
    
    Returns:
        랩 타임 DataFrame (드라이버, 랩번호, 랩타임, 섹터타임 등)
    """
    laps = session.laps
    return laps[['Driver', 'LapNumber', 'LapTime', 'Sector1Time', 'Sector2Time', 
                 'Sector3Time', 'Compound', 'TyreLife', 'IsPersonalBest']].copy()


def get_telemetry(session: fastf1.core.Session, driver: str, lap_number: int = None) -> pd.DataFrame:
    """
    특정 드라이버의 텔레메트리 데이터를 가져옵니다.
    
    Args:
        session: FastF1 Session 객체
        driver: 드라이버 약어 (예: "VER", "HAM", "LEC")
        lap_number: 특정 랩 번호 (None이면 가장 빠른 랩)
    
    Returns:
        텔레메트리 DataFrame (속도, 스로틀, 브레이크, 기어, RPM 등)
    """
    driver_laps = session.laps.pick_driver(driver)
    
    if lap_number:
        lap = driver_laps[driver_laps['LapNumber'] == lap_number].iloc[0]
    else:
        lap = driver_laps.pick_fastest()
    
    telemetry = lap.get_telemetry()
    return telemetry


def get_race_results(year: int, grand_prix: str) -> pd.DataFrame:
    """
    레이스 결과를 가져옵니다.
    
    Returns:
        레이스 결과 DataFrame (순위, 드라이버, 팀, 포인트 등)
    """
    session = get_session_data(year, grand_prix, "R")
    results = session.results
    return results[['Position', 'Abbreviation', 'TeamName', 'GridPosition', 
                    'Status', 'Points', 'Time']].copy()


def get_season_schedule(year: int) -> pd.DataFrame:
    """
    시즌 전체 일정을 가져옵니다.
    
    Returns:
        시즌 일정 DataFrame
    """
    schedule = fastf1.get_event_schedule(year)
    return schedule


def get_driver_standings(session: fastf1.core.Session) -> pd.DataFrame:
    """
    세션 시점의 드라이버 스탠딩을 가져옵니다.
    """
    return session.results[['Position', 'Abbreviation', 'TeamName', 'Points']].sort_values('Position')


def get_weather_data(session: fastf1.core.Session) -> pd.DataFrame:
    """
    세션 중 날씨 데이터를 가져옵니다.
    
    Returns:
        날씨 DataFrame (기온, 트랙온도, 습도, 풍속 등)
    """
    return session.weather_data


# ============================================
# 사용 예시
# ============================================
if __name__ == "__main__":
    print("=" * 60)
    print("FastF1 데이터 수집 예시")
    print("=" * 60)
    
    # 2024 바레인 GP 레이스 세션 로드
    print("\n[1] 2024 바레인 GP 레이스 데이터 로딩 중...")
    session = get_session_data(2024, "Bahrain", "R")
    print(f"    ✓ 세션 로드 완료: {session.event['EventName']}")
    
    # 랩 타임 데이터
    print("\n[2] 랩 타임 데이터:")
    lap_times = get_lap_times(session)
    print(lap_times.head(10))
    
    # 레이스 결과
    print("\n[3] 레이스 결과:")
    results = session.results[['Position', 'Abbreviation', 'TeamName', 'Points']]
    print(results.head(10))
    
    # 베르스타펜 가장 빠른 랩 텔레메트리
    print("\n[4] VER 가장 빠른 랩 텔레메트리:")
    telemetry = get_telemetry(session, "VER")
    print(telemetry[['Speed', 'Throttle', 'Brake', 'nGear', 'RPM']].head(10))
    
    # 날씨 데이터
    print("\n[5] 날씨 데이터:")
    weather = get_weather_data(session)
    print(weather.head())
    
    # 2024 시즌 일정
    print("\n[6] 2024 시즌 일정:")
    schedule = get_season_schedule(2024)
    print(schedule[['RoundNumber', 'EventName', 'Country', 'EventDate']].head(10))
    
    print("\n" + "=" * 60)
    print("데이터 수집 완료!")
    print("=" * 60)



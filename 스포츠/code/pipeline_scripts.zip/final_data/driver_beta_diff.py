# -*- coding: utf-8 -*-
"""
드라이버별 회귀 베타 − 전체 표본 회귀 베타 = 차이(diff)
- 드라이버별로 회귀한 각 실력지표 베타와, 모든 표본에 회귀한 베타의 차이를 계산
- 유의하지 않더라도 드라이버별 베타를 그대로 채택
- 전체 표본 베타: 선수 고정효과 회귀(regression_driver_fe_summary.txt)의 공통 베타
"""

import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
COEF_CSV = BASE_DIR / "driver_regression_coefs.csv"
FE_SUMMARY_TXT = BASE_DIR / "regression_driver_fe_summary.txt"
OUT_CSV = BASE_DIR / "driver_beta_diff.csv"

# 전체 표본 회귀 베타: 선수 고정효과 회귀(regression_driver_fe_summary.txt)의 공통 계수 4개
VAR_NAMES = [
    "Tyre_Management_minmax_0_10",
    "overall_pace_score_minmax_0_10",
    "overtake_total_score_minmax_0_10",
    "Stability_minmax_0_10",
]
COEF_KEYS = ["coef_" + v for v in VAR_NAMES]
DIFF_NAMES = ["diff_Tyre", "diff_Pace", "diff_Overtake", "diff_Stability"]


def load_beta_full() -> dict:
    """regression_driver_fe_summary.txt에서 4개 실력지표 공통 베타 파싱."""
    beta = {k: np.nan for k in COEF_KEYS}
    if not FE_SUMMARY_TXT.exists():
        return beta
    with open(FE_SUMMARY_TXT, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 2 and parts[0] in VAR_NAMES:
                idx = VAR_NAMES.index(parts[0])
                try:
                    beta[COEF_KEYS[idx]] = float(parts[1])
                except ValueError:
                    pass
    return beta


def main():
    BETA_FULL = load_beta_full()
    if np.any(np.isnan(list(BETA_FULL.values()))):
        raise FileNotFoundError(
            "전체 표본 베타를 읽지 못함. {} 실행 후 {} 확인.".format(
                "regression_driver_fixed_effects.py", FE_SUMMARY_TXT.name
            )
        )
    df = pd.read_csv(COEF_CSV)
    out = df[["Driver", "n_races"]].copy()

    # 드라이버별 베타 (유의 여부 무관, 그대로 사용) → 차이 = 드라이버 베타 − 전체 표본 베타
    short = ["Tyre", "Pace", "Overtake", "Stability"]
    for i, col in enumerate(COEF_KEYS):
        out[f"coef_{short[i]}"] = df[col].values
        out[DIFF_NAMES[i]] = df[col].values - BETA_FULL[col]

    # p-value 참고용
    pval_cols = [c.replace("coef_", "pval_") for c in COEF_KEYS]
    for i, col in enumerate(pval_cols):
        if col in df.columns:
            out[f"pval_{short[i]}"] = df[col].values

    # 성향 요약: diff > 0 = 해당 X가 평균보다 더 큰 비중을 차지
    for i, name in enumerate(short):
        out[f"above_avg_{name}"] = out[DIFF_NAMES[i]].gt(0)
    # dominant_tendency: 4개 diff 중 가장 큰 diff에 해당하는 지표명 (유효한 diff만 사용)
    diff_arr = out[DIFF_NAMES].values
    valid_mask = ~np.isnan(diff_arr)
    dominant = []
    for i in range(len(out)):
        row = diff_arr[i]
        if np.any(valid_mask[i]):
            valid_vals = np.where(valid_mask[i], row, -np.inf)
            idx_max = np.argmax(valid_vals)
            dominant.append(short[idx_max])
        else:
            dominant.append("")
    out["dominant_tendency"] = dominant

    # n_races > 24 인 드라이버만 포함 (24 이하 제외)
    out = out[out["n_races"] > 24].copy()
    out = out.reset_index(drop=True)

    out.to_csv(OUT_CSV, index=False)
    print("전체 표본 베타 (기준):")
    for k, v in BETA_FULL.items():
        print(f"  {k}: {v}")
    print(f"\n저장: {OUT_CSV} (n_races > 24, {len(out)}명)")
    print("\n차이(diff) 요약:")
    for d in DIFF_NAMES:
        s = out[d]
        print(f"  {d}: mean={s.mean():.4f}, std={s.std():.4f}, min={s.min():.4f}, max={s.max():.4f}")
    print("\n상위 5명 (diff_Tyre 기준):")
    print(out.nlargest(5, "diff_Tyre")[["Driver", "n_races", "coef_Tyre", "diff_Tyre"]].to_string(index=False))


if __name__ == "__main__":
    main()

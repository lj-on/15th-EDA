# -*- coding: utf-8 -*-
"""
베타 비율 가중치 기반 드라이버 실력지표 (100점 만점)
- 회귀(선수 고정효과)에서 얻은 4개 실력지표 베타의 비율로 가중치 정의
- 차량(Car_Score)은 드라이버 실력과 무관하므로 가중치·실력지표 산출에서 제외
- 가중합을 100점 만점으로 환산. 출력 CSV의 4개 지표 평균도 0~100 스케일로 명시.
"""

import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MERGED_CSV = BASE_DIR / "f1_merged_final_beta.csv"
FE_SUMMARY_TXT = BASE_DIR / "regression_driver_fe_summary.txt"
OUT_CSV = BASE_DIR / "driver_skill_weighted_100.csv"

VAR_NAMES = [
    "Tyre_Management_minmax_0_10",
    "overall_pace_score_minmax_0_10",
    "overtake_total_score_minmax_0_10",
    "Stability_minmax_0_10",
]

PREDICTOR_COLS = VAR_NAMES.copy()
SHORT_NAMES = ["Tyre", "Pace", "Overtake", "Stability"]


def load_betas_from_fe_summary():
    """regression_driver_fe_summary.txt에서 4개 실력지표 공통 베타 파싱."""
    found = {}
    if not FE_SUMMARY_TXT.exists():
        return None
    with open(FE_SUMMARY_TXT, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 2 and parts[0] in VAR_NAMES:
                try:
                    found[parts[0]] = float(parts[1])
                except ValueError:
                    pass
    if len(found) != 4:
        return None
    return [found[v] for v in VAR_NAMES]


def main():
    betas = load_betas_from_fe_summary()
    if betas is None or len(betas) != 4:
        raise FileNotFoundError(
            "4개 실력지표 베타를 읽지 못함. regression_driver_fixed_effects.py 실행 후 {} 확인.".format(
                FE_SUMMARY_TXT.name
            )
        )
    beta_sum = sum(betas)
    WEIGHTS = {col: b / beta_sum for col, b in zip(PREDICTOR_COLS, betas)}

    df = pd.read_csv(MERGED_CSV)
    use_cols = ["Driver"] + PREDICTOR_COLS
    use = df[use_cols].dropna(how="any")

    agg = use.groupby("Driver")[PREDICTOR_COLS].mean()
    n_races = use.groupby("Driver").size()

    # Overtake 분포 편향 해소: 드라이버 간 순위(퍼센타일) 기반 재스케일 [0, 10]
    # - 값의 절대 크기보다 "다른 드라이버 대비 어디쯤인지"를 반영
    mean_O = agg[PREDICTOR_COLS[2]].values  # overtake_total_score_minmax_0_10 평균
    n_drivers = len(mean_O)
    if n_drivers <= 1:
        # 드라이버가 1명 뿐이면 중간값 5 부여
        o_rescaled = np.full_like(mean_O, 5.0, dtype=float)
    else:
        order = np.argsort(mean_O)
        ranks = np.empty(n_drivers, dtype=float)
        ranks[order] = np.arange(n_drivers)
        percentiles = ranks / (n_drivers - 1)  # 0~1
        o_rescaled = percentiles * 10.0  # [0, 10]

    weighted_sum = np.zeros(len(agg))
    for i, col in enumerate(PREDICTOR_COLS):
        if col == PREDICTOR_COLS[2]:
            weighted_sum += WEIGHTS[col] * o_rescaled
        else:
            weighted_sum += WEIGHTS[col] * agg[col].values

    skill_100 = 10.0 * weighted_sum

    # 0~10 평균을 0~100 스케일로 저장 (명시적 컬럼명). Overtake는 원시 평균 + 재스케일 값 둘 다 출력
    out = pd.DataFrame({
        "Driver": agg.index,
        "n_races": n_races.reindex(agg.index).values,
        "mean_Tyre_0_100": agg[PREDICTOR_COLS[0]].values * 10,
        "mean_Pace_0_100": agg[PREDICTOR_COLS[1]].values * 10,
        "mean_Overtake_0_100": agg[PREDICTOR_COLS[2]].values * 10,
        "Overtake_rescaled_0_100": o_rescaled * 10,
        "mean_Stability_0_100": agg[PREDICTOR_COLS[3]].values * 10,
        "skill_score_0_100": skill_100,
    })

    eval_set = out[out["n_races"] > 24].copy()
    eval_set = eval_set.sort_values("skill_score_0_100", ascending=False).reset_index(drop=True)
    eval_set["rank"] = range(1, len(eval_set) + 1)
    out = eval_set

    out.to_csv(OUT_CSV, index=False)
    print("베타 (FE 회귀):", [round(b, 4) for b in betas])
    print("가중치 (베타 비율, 합=1):")
    for col, w in WEIGHTS.items():
        print("  {}: {:.4f}".format(col, w))
    print("저장: {} (n_races > 24, {}명)".format(OUT_CSV, len(out)))
    print("컬럼: Driver, n_races, mean_*_0_100(4개), skill_score_0_100, rank (Overtake 재스케일 미적용)")
    print("\n상위 10명:")
    print(out[["Driver", "n_races", "skill_score_0_100", "rank"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()

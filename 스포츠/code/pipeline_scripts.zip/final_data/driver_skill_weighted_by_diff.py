# -*- coding: utf-8 -*-
"""
diff 기반 드라이버별 가중치로 실력지표 종합 (100점 만점) — 대안용.

diff의 주 용도는 드라이버 성향(해당 X가 평균보다 더 큰 비중을 차지함)을 드러내는 것이며,
실력 점수로 환산하지 않는 것이 기본이다. 본 스크립트는 diff를 가중치에 반영해
점수를 산출하는 참고/대안용이며, 성향 분석의 주 출력(driver_beta_diff.csv)이 아니다.

- 유효 베타 = max(ε, 전체 베타 + diff), 가중치 = 유효 베타 비율 (합=1)
- 4개 실력지표 평균의 가중합 × 10 → 0~100점 (차량 제외)
"""

import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MERGED_CSV = BASE_DIR / "f1_merged_final_beta.csv"
DIFF_CSV = BASE_DIR / "driver_beta_diff.csv"
OUT_CSV = BASE_DIR / "driver_skill_score_by_diff.csv"

# 전체 표본 베타 (선수 고정효과 회귀, 4개 실력지표만)
BETA_FULL = np.array([1.0276, 1.1920, 0.4706, 0.3673])
EPS = 0.01  # 유효 베타 최소값 (가중치 양수 유지)

PREDICTOR_COLS = [
    "Tyre_Management_minmax_0_10",
    "overall_pace_score_minmax_0_10",
    "overtake_total_score_minmax_0_10",
    "Stability_minmax_0_10",
]
DIFF_COLS = ["diff_Tyre", "diff_Pace", "diff_Overtake", "diff_Stability"]


def main():
    # 1) 드라이버별 4개 실력지표 평균
    df = pd.read_csv(MERGED_CSV)
    use = df[["Driver"] + PREDICTOR_COLS].dropna(how="any")
    means = use.groupby("Driver")[PREDICTOR_COLS].mean()
    n_races = use.groupby("Driver").size()

    # 2) diff 로드
    diff_df = pd.read_csv(DIFF_CSV)[["Driver", "n_races"] + DIFF_COLS].copy()

    # 3) 드라이버별 가중치: 유효 베타 = max(ε, full_beta + diff), 정규화
    drivers = means.index.tolist()
    skill_scores = []
    weight_rows = []

    for driver in drivers:
        if driver not in diff_df["Driver"].values:
            # diff 없으면 전체 표본 가중치 사용
            w = BETA_FULL / BETA_FULL.sum()
        else:
            row = diff_df[diff_df["Driver"] == driver].iloc[0]
            diffs = np.array([row[c] for c in DIFF_COLS], dtype=float)
            if np.any(pd.isna(diffs)):
                w = BETA_FULL / BETA_FULL.sum()
            else:
                effective = np.maximum(EPS, BETA_FULL + diffs)
                w = effective / effective.sum()
        weight_rows.append(w)

        # 가중합 (0~10) × 10 → 0~100
        x = means.loc[driver].values
        score = 10.0 * np.dot(w, x)
        skill_scores.append(score)

    out = pd.DataFrame({
        "Driver": drivers,
        "n_races": n_races.reindex(drivers).values,
        "mean_Tyre": means[PREDICTOR_COLS[0]].values,
        "mean_Pace": means[PREDICTOR_COLS[1]].values,
        "mean_Overtake": means[PREDICTOR_COLS[2]].values,
        "mean_Stability": means[PREDICTOR_COLS[3]].values,
        "skill_score_diff_0_100": skill_scores,
    })
    # 드라이버별 가중치 (참고)
    for i, k in enumerate(["w_Tyre", "w_Pace", "w_Overtake", "w_Stability"]):
        out[k] = [wr[i] for wr in weight_rows]

    # 평가대상: n_races > 24
    eval_set = out[out["n_races"] > 24].copy()
    eval_set = eval_set.sort_values("skill_score_diff_0_100", ascending=False).reset_index(drop=True)
    eval_set["rank"] = range(1, len(eval_set) + 1)
    eval_set.to_csv(OUT_CSV, index=False)

    print("방법 A: 드라이버별 가중치(전체 베타 + diff) → 4개 지표 가중합 × 10 = 0~100점")
    print(f"저장: {OUT_CSV} (n_races > 24, {len(eval_set)}명)")
    print("\n상위 10명:")
    print(eval_set[["Driver", "n_races", "skill_score_diff_0_100", "rank"]].head(10).to_string(index=False))
    print("\n예시 가중치 (VER):")
    ver = eval_set[eval_set["Driver"] == "VER"].iloc[0]
    for k in ["w_Tyre", "w_Pace", "w_Overtake", "w_Stability"]:
        print(f"  {k}: {ver[k]:.4f}")


if __name__ == "__main__":
    main()

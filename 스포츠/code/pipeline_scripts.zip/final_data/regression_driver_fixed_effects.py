# -*- coding: utf-8 -*-
"""
선수 고정효과 회귀 (Driver Fixed Effects)
- Y = rank_value
- 설명변수: 차량 통제 변수(Car_Score_Scaled_GP) + 네 가지 선수 성능 지표(Tyre, Pace, Overtake, Stability)
- 선수별 더미변수(선수 고정효과) 포함
- 더미 회귀계수 = 관측 가능한 성능 지표·차량 특성으로 설명되지 않는 선수의 잠재적 능력(latent ability)
"""

import pandas as pd
import numpy as np
from pathlib import Path

import sys
_base = Path(__file__).resolve().parent
sys.path.insert(0, str(_base.parent))
from regression_gp_final_position import (
    build_gp_level_df,
    PREDICTOR_COLS,
    CONFOUNDER_COLS,
)

try:
    import statsmodels.api as sm
except ImportError:
    sm = None

BASE_DIR = Path(__file__).resolve().parent
FINAL_DIR = BASE_DIR
SUMMARY_PATH = FINAL_DIR / "regression_driver_fe_summary.txt"
LATENT_CSV = FINAL_DIR / "driver_latent_ability_fe.csv"


def main():
    if sm is None:
        raise ImportError("statsmodels 필요: pip install statsmodels")

    gp = build_gp_level_df()
    y_col = "rank_value"
    covar_cols = PREDICTOR_COLS + CONFOUNDER_COLS  # 성능 지표 4개 + 차량 통제 1개
    all_cols = [y_col] + covar_cols + ["Driver"]
    use = gp[all_cols].dropna(how="any")
    use = use.reset_index(drop=True)

    # 선수 더미: drop_first=True → 기준 선수 1명 제외 (다중공선성 방지)
    driver_dummies = pd.get_dummies(use["Driver"], prefix="Driver", drop_first=True)
    # pandas get_dummies(drop_first=True)는 정렬 시 첫 번째 카테고리를 제외
    reference_driver = sorted(use["Driver"].unique())[0]

    # 설계행렬: 상수 + 공변량(성능지표+차량) + 선수 더미 (statsmodels는 float 필요)
    X_cov = use[covar_cols]
    X = pd.concat([X_cov, driver_dummies.astype(np.float64)], axis=1)
    X = sm.add_constant(X, has_constant="add")
    y = use[y_col]

    model = sm.OLS(y, X.astype(np.float64)).fit()
    print(model.summary())

    # 서머리 저장
    FINAL_DIR.mkdir(parents=True, exist_ok=True)
    with open(SUMMARY_PATH, "w", encoding="utf-8") as f:
        f.write("선수 고정효과 회귀 (Driver Fixed Effects)\n")
        f.write("Y = rank_value | 설명변수: 차량 통제 + 4가지 성능 지표 + 선수 더미\n")
        f.write("기준 선수(참조): {}\n".format(reference_driver))
        f.write("=" * 60 + "\n\n")
        f.write(str(model.summary()))
    print(f"\n서머리 저장: {SUMMARY_PATH}")

    # 선수별 잠재적 능력 = 더미 계수 (기준 선수는 0)
    fe_params = model.params
    n_races = use.groupby("Driver").size()

    rows = []
    for driver in use["Driver"].unique():
        n = int(n_races.get(driver, 0))
        if driver == reference_driver:
            latent = 0.0
        else:
            key = "Driver_" + driver
            latent = float(fe_params.get(key, np.nan))
        rows.append({"Driver": driver, "n_races": n, "latent_ability": latent})

    out = pd.DataFrame(rows)
    # 평가대상: n_races > 24 만 (해설 §2.4)
    out = out[out["n_races"] > 24].copy().reset_index(drop=True)
    la = out["latent_ability"]
    lo, hi = la.min(), la.max()
    if hi > lo:
        out["latent_ability_0_10"] = 10.0 * (la - lo) / (hi - lo)
    else:
        out["latent_ability_0_10"] = 5.0 if not pd.isna(hi) else np.nan
    out["rank"] = out["latent_ability"].rank(ascending=False, method="min", na_option="bottom").astype(int)
    out = out.sort_values("rank").reset_index(drop=True)
    out.to_csv(LATENT_CSV, index=False)
    print(f"선수별 잠재적 능력 저장: {LATENT_CSV} (n_races > 24, {len(out)}명)")
    print("\n기준 선수(잠재능력=0):", reference_driver)
    print("\n잠재적 능력(latent_ability) 상위 10:")
    print(out[["Driver", "n_races", "latent_ability", "latent_ability_0_10", "rank"]].head(10).to_string(index=False))


if __name__ == "__main__":
    main()

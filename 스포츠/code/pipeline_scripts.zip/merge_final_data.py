# -*- coding: utf-8 -*-
"""
final_data 폴더 내 데이터셋 병합 스크립트
- 베이스: data/merged/f1_main_analysis.csv (또는 final_data/f1_main_analysisinstability.csv)
- 병합: driver_pace, f1_car_performance, overtake 점수, hard/med 타이어 Beta, Instability
"""

import pandas as pd
import os
from pathlib import Path

# 경로
BASE_DIR = Path(__file__).resolve().parent
FINAL_DIR = BASE_DIR / "final_data"
MERGED_DIR = BASE_DIR / "data" / "merged"
OUT_DIR = BASE_DIR / "final_data"  # 병합 결과도 final_data에 저장

# grand_prix (overtake) -> event_mapping RaceShortName 별칭 (overtake 파일 값이 다를 때)
GP_ALIAS = {
    "Australia": "Australian",
    "Austria": "Austrian",
    "Brazil": "Brazilian",
    "Britain": "British",
    "Great Britain": "British",
    "Belgium": "Belgian",
    "Germany": "German",
    "Italy": "Italian",
    "Japan": "Japanese",
    "Mexico": "Mexican",
    "USA": "United States",
    "United States": "United States",
    "Monaco": "Monaco",
    "Spain": "Spanish",
    "Canada": "Canadian",
    "France": "French",
    "Hungary": "Hungarian",
    "Russia": "Russian",
    "China": "Chinese",
    "Singapore": "Singapore",
    "Netherlands": "Dutch",
    "Saudi Arabia": "Saudi Arabian",
    "Mexico City": "Mexico City",
    "Portugal": "Portuguese",
    "Turkey": "Turkish",
    "Styria": "Styrian",
    "Sakhir": "Sakhir",
    "Tuscany": "Tuscan",
    "Eifel": "Eifel",
    "70th Anniversary": "70th Anniversary",
    "Emilia-Romagna": "Emilia Romagna",
}


def load_event_mapping():
    """EventName, Round 매핑 로드 (grand_prix -> EventName 변환용)"""
    path = MERGED_DIR / "event_mapping.csv"
    if not path.exists():
        raise FileNotFoundError(f"event_mapping 없음: {path}")
    em = pd.read_csv(path)
    # RaceShortName 별칭 적용용 컬럼
    em["grand_prix_key"] = em["RaceShortName"]
    return em


def load_driver_name_mapping():
    """드라이버 풀네임 -> 3글자 코드"""
    path = FINAL_DIR / "driver_name_to_code.csv"
    if not path.exists():
        raise FileNotFoundError(f"driver_name_to_code 없음: {path}")
    return pd.read_csv(path)


def load_base_with_instability():
    """베이스: instability 포함 메인 분석 (final_data 쪽 사용)"""
    path = FINAL_DIR / "f1_main_analysisinstability.csv"
    if path.exists():
        return pd.read_csv(path)
    path = FINAL_DIR / "f1_main_analysis.csv"
    if path.exists():
        return pd.read_csv(path)
    path = MERGED_DIR / "f1_main_analysis.csv"
    if path.exists():
        return pd.read_csv(path)
    raise FileNotFoundError("f1_main_analysis 또는 f1_main_analysisinstability 없음")


def normalize_eventname(s: str) -> str:
    """Race 형식 'Australian_Grand_Prix' -> 'Australian Grand Prix'"""
    if pd.isna(s):
        return s
    return str(s).replace("_", " ").strip()


def merge_driver_pace(base: pd.DataFrame) -> pd.DataFrame:
    """driver_pace: GP당 드라이버별 페이스 점수 (race level)"""
    path = FINAL_DIR / "driver_pace.csv"
    if not path.exists():
        return base
    dp = pd.read_csv(path)
    dp = dp.rename(columns={"eventname": "EventName", "year": "Year", "round": "Round", "driver": "Driver"})
    cols = [c for c in ["Year", "Round", "EventName", "Driver", "qualifying_pace", "race_pace", "qp_score", "rp_score", "overall_pace_score"] if c in dp.columns]
    dp = dp[cols].drop_duplicates(subset=["Year", "Round", "Driver"])
    base = base.merge(dp, on=["Year", "Round", "EventName", "Driver"], how="left", suffixes=("", "_pace"))
    return base


# f1_car_performance.csv 내 드라이버 코드가 베이스(메인 분석)와 다를 때: (Year, CP_Driver) -> Base_Driver
# 2018: CP에 SAR(McLaren) = 베이스의 VAN(Stoffel Vandoorne). Logan Sargeant(SAR)는 2023~.
CAR_PERFORMANCE_DRIVER_FIX = {(2018, "SAR"): "VAN"}


def merge_car_performance(base: pd.DataFrame) -> pd.DataFrame:
    """f1_car_performance: Race -> EventName 변환 후 GP당 대표 차량 성능 (한 row per driver per event)"""
    path = FINAL_DIR / "f1_car_performance.csv"
    if not path.exists():
        return base
    cp = pd.read_csv(path)
    # 매핑 오류 보정: CP에는 SAR(2018 McLaren)인데 베이스는 VAN
    for (yr, wrong_code), right_code in CAR_PERFORMANCE_DRIVER_FIX.items():
        cp.loc[(cp["Year"] == yr) & (cp["Driver"] == wrong_code), "Driver"] = right_code
    cp["EventName"] = cp["Race"].apply(normalize_eventname)
    score_cols = [c for c in ["Car_Score_Scaled", "Car_Score_Mixed", "Car_Score_Original"] if c in cp.columns]
    if not score_cols:
        return base
    agg = cp.groupby(["Year", "Round", "Driver"], as_index=False)[score_cols].first()
    agg = agg.rename(columns={c: c + "_GP" for c in score_cols})
    base = base.merge(agg, on=["Year", "Round", "Driver"], how="left")
    return base


def merge_overtake_scores(base: pd.DataFrame, event_mapping: pd.DataFrame, driver_name_map: pd.DataFrame) -> pd.DataFrame:
    """f1_driver_scores_by_grand_prix_overtake: grand_prix -> EventName, driver 풀네임 -> Driver"""
    path = FINAL_DIR / "f1_driver_scores_by_grand_prix_overtake.csv"
    if not path.exists():
        return base
    ov = pd.read_csv(path)
    # 그랑프리명 → RaceShortName: 1) GP_ALIAS(짧은 이름), 2) EventName→RaceShortName(풀네임 '~ Grand Prix' 대응)
    event_to_short = event_mapping.drop_duplicates("EventName").set_index("EventName")["RaceShortName"].to_dict()
    if "São Paulo Grand Prix" in event_to_short:
        event_to_short["Sao Paulo Grand Prix"] = event_to_short["São Paulo Grand Prix"]
    ov["grand_prix_key"] = ov["grand_prix"].map(lambda x: GP_ALIAS.get(x, event_to_short.get(x, x)))
    em = event_mapping[["Year", "EventName", "grand_prix_key", "Round"]].drop_duplicates()
    ov = ov.merge(em, left_on=["year", "grand_prix_key"], right_on=["Year", "grand_prix_key"], how="left")
    ov = ov.merge(driver_name_map, left_on="driver", right_on="driver_full_name", how="left")
    ov["Driver"] = ov["Driver"].fillna(ov["driver"])  # 매핑 실패 시 원본 유지
    ov = ov[["Year", "Round", "EventName", "Driver", "total_score"]].drop_duplicates(subset=["Year", "Round", "Driver"])
    ov = ov.rename(columns={"total_score": "overtake_total_score"})
    base = base.merge(ov, on=["Year", "Round", "EventName", "Driver"], how="left")
    return base


def merge_tyre_beta(base: pd.DataFrame) -> pd.DataFrame:
    """hard_all.csv, med_all.csv, soft_all.csv: Year, EventName, Driver, Stint, Compound -> Beta"""
    for compound, fname in [("HARD", "hard_all.csv"), ("MEDIUM", "med_all.csv"), ("SOFT", "soft_all.csv")]:
        path = FINAL_DIR / fname
        if not path.exists():
            continue
        tb = pd.read_csv(path)
        if tb.columns[0].strip() == "" or str(tb.columns[0]).startswith("Unnamed"):
            tb = tb.iloc[:, 1:]
        tb = tb.rename(columns={c: str(c).strip() for c in tb.columns})
        if "Beta" not in tb.columns:
            continue
        tb = tb[["Year", "EventName", "Driver", "Stint", "Compound", "Beta"]].copy()
        tb["Compound"] = tb["Compound"].astype(str).str.upper()
        tb = tb[tb["Compound"] == compound]
        tb = tb.rename(columns={"Beta": f"Beta_{compound}"}).drop(columns=["Compound"], errors="ignore")
        base = base.merge(tb, on=["Year", "EventName", "Driver", "Stint"], how="left")
    # 드라이버·GP별로 Beta 한 번이라도 있으면 해당 GP 모든 랩에 전파 (GP 단위 분석용)
    beta_cols = [c for c in ["Beta_HARD", "Beta_MEDIUM", "Beta_SOFT"] if c in base.columns]
    for col in beta_cols:
        base[col] = base.groupby(["Year", "Round", "EventName", "Driver"], group_keys=False)[col].apply(
            lambda s: s.ffill().bfill() if s.notna().any() else s
        )
    return base


def merge_tyre_beta_from_beta_table(base: pd.DataFrame) -> pd.DataFrame:
    """beta.csv (모든 컴파운드): Year, EventName, Driver, Stint, Compound -> Beta 한 컬럼"""
    path = FINAL_DIR / "beta.csv"
    if not path.exists():
        return base
    tb = pd.read_csv(path)
    if tb.columns[0].strip() == "" or str(tb.columns[0]).startswith("Unnamed"):
        tb = tb.iloc[:, 1:]
    tb = tb.rename(columns={c: str(c).strip() for c in tb.columns})
    if "Beta" not in tb.columns or "Compound" not in tb.columns:
        return base
    tb = tb[["Year", "EventName", "Driver", "Stint", "Compound", "Beta"]].copy()
    tb["Compound"] = tb["Compound"].astype(str).str.upper()
    base_compound = base["Compound"].astype(str).str.upper() if "Compound" in base.columns else None
    if base_compound is None:
        return base
    base = base.merge(tb, on=["Year", "EventName", "Driver", "Stint", "Compound"], how="left")
    base["Beta"] = base.groupby(["Year", "Round", "EventName", "Driver"], group_keys=False)["Beta"].apply(
        lambda s: s.ffill().bfill() if s.notna().any() else s
    )
    return base


def _minmax_0_10(series: pd.Series) -> pd.Series:
    """0~10 min-max 스케일링"""
    s = series.dropna()
    if len(s) == 0 or s.min() == s.max():
        return series
    return 10.0 * (series - s.min()) / (s.max() - s.min())


def to_gp_level_trimmed(base: pd.DataFrame, use_beta_table: bool = False) -> pd.DataFrame:
    """GP(레이스)·드라이버별 1행으로 집계, 회귀에 쓰는 열 + 원점수만 유지.
    use_beta_table: True면 Beta(단일) 기준, False면 Beta_HARD/MEDIUM/SOFT 기준."""
    agg = {
        "FinalPosition": "first",
        "Team": "first",
        "overall_pace_score": "first",
        "overtake_total_score": "first",
        "Instability": "mean",
        "Instability_minmax_0_10": "mean",
        "Car_Score_Scaled_GP": "first",
    }
    if use_beta_table and "Beta" in base.columns:
        agg["Beta"] = "mean"
    else:
        for c in ["Beta_HARD", "Beta_MEDIUM", "Beta_SOFT", "Beta_HARD_minmax_0_10", "Beta_MEDIUM_minmax_0_10", "Beta_SOFT_minmax_0_10"]:
            if c in base.columns:
                agg[c] = "mean"
    gp = base.groupby(["Year", "Round", "EventName", "Driver"], as_index=False).agg(agg)
    gp["max_pos"] = gp.groupby(["Year", "Round"])["FinalPosition"].transform("max")
    gp["rank_value"] = gp["max_pos"] - gp["FinalPosition"] + 1
    gp = gp.drop(columns=["max_pos"])
    if use_beta_table and "Beta" in gp.columns:
        gp["Beta_tyre_minmax_0_10"] = _minmax_0_10(gp["Beta"])
    else:
        beta_cols = [c for c in ["Beta_HARD_minmax_0_10", "Beta_MEDIUM_minmax_0_10", "Beta_SOFT_minmax_0_10"] if c in gp.columns]
        gp["Beta_tyre_minmax_0_10"] = gp[beta_cols].mean(axis=1, skipna=True) if beta_cols else float("nan")
    gp["overall_pace_score_minmax_0_10"] = _minmax_0_10(gp["overall_pace_score"])
    gp["overtake_total_score"] = gp["overtake_total_score"].fillna(0)
    gp["overtake_total_score_minmax_0_10"] = _minmax_0_10(gp["overtake_total_score"])
    # 실력지표: 낮을수록 좋았던 것 → 반전(minmax 10-x) so 높을수록 좋은 지표
    gp["Tyre_Management_minmax_0_10"] = 10.0 - gp["Beta_tyre_minmax_0_10"]
    gp["Stability_minmax_0_10"] = 10.0 - gp["Instability_minmax_0_10"]
    keep = [
        "Year", "Round", "EventName", "Driver", "Team", "FinalPosition", "rank_value",
        "overall_pace_score", "overtake_total_score", "Instability",
        "Beta_tyre_minmax_0_10", "Tyre_Management_minmax_0_10", "Instability_minmax_0_10", "Stability_minmax_0_10",
        "overall_pace_score_minmax_0_10", "overtake_total_score_minmax_0_10",
        "Car_Score_Scaled_GP",
    ]
    if use_beta_table and "Beta" in gp.columns:
        keep.insert(keep.index("Beta_tyre_minmax_0_10"), "Beta")
    else:
        for c in ["Beta_HARD", "Beta_MEDIUM", "Beta_SOFT"]:
            if c in gp.columns and c not in keep:
                keep.insert(keep.index("Beta_tyre_minmax_0_10"), c)
    keep = [c for c in keep if c in gp.columns]
    return gp[keep]


def minmax_scale_beta_0_10(base: pd.DataFrame) -> pd.DataFrame:
    """Beta_HARD, Beta_MEDIUM, Beta_SOFT를 0~10 범위로 min-max 정규화한 새 열 추가 (_minmax_0_10)"""
    for col in ["Beta_HARD", "Beta_MEDIUM", "Beta_SOFT"]:
        if col not in base.columns:
            continue
        new_col = col + "_minmax_0_10"
        vals = base[col].dropna()
        if len(vals) == 0:
            base[new_col] = float("nan")
            continue
        vmin, vmax = vals.min(), vals.max()
        if vmax == vmin:
            base[new_col] = 5.0  # 상수면 5
        else:
            base[new_col] = base[col].apply(
                lambda x: 10.0 * (x - vmin) / (vmax - vmin) if pd.notna(x) else float("nan")
            )
    return base


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    event_mapping = load_event_mapping()
    driver_name_map = load_driver_name_mapping()
    base = load_base_with_instability()

    # 컬럼명 통일 (소문자 year/round 있으면 Year, Round로)
    for c in ["year", "round", "eventname"]:
        if c in base.columns and c.capitalize() in ["Year", "Round", "Eventname"]:
            cap = "EventName" if c == "eventname" else c.capitalize()
            if cap not in base.columns:
                base = base.rename(columns={c: cap})

    base = merge_driver_pace(base)
    base = merge_car_performance(base)
    base = merge_overtake_scores(base, event_mapping, driver_name_map)
    base = merge_tyre_beta(base)
    base = minmax_scale_beta_0_10(base)

    # 레이스(GP)별 1행으로 집계, 회귀용·원점수 열만 유지
    gp = to_gp_level_trimmed(base, use_beta_table=False)
    out_path = OUT_DIR / "f1_merged_final_all.csv"
    gp.to_csv(out_path, index=False)
    print(f"저장: {out_path}  (행={len(gp):,}, 열={len(gp.columns)} [GP 단위, hard/med/soft_all])")

    # beta.csv(모든 컴파운드) 기준 타이어 업데이트 테이블
    base_beta = load_base_with_instability()
    for c in ["year", "round", "eventname"]:
        if c in base_beta.columns and c.capitalize() in ["Year", "Round", "Eventname"]:
            cap = "EventName" if c == "eventname" else c.capitalize()
            if cap not in base_beta.columns:
                base_beta = base_beta.rename(columns={c: cap})
    base_beta = merge_driver_pace(base_beta)
    base_beta = merge_car_performance(base_beta)
    base_beta = merge_overtake_scores(base_beta, event_mapping, driver_name_map)
    base_beta = merge_tyre_beta_from_beta_table(base_beta)
    gp_beta = to_gp_level_trimmed(base_beta, use_beta_table=True)
    out_beta = OUT_DIR / "f1_merged_final_beta.csv"
    gp_beta.to_csv(out_beta, index=False)
    print(f"저장: {out_beta}  (행={len(gp_beta):,}, 열={len(gp_beta.columns)} [GP 단위, beta.csv 타이어])")
    return gp


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
그랑프리별 다중회귀 (Car_Score_Scaled_GP = 교란변수, 컨디셔닝)
- 관심 설명변수: Beta_tyre_minmax_0_10 (HARD/MEDIUM 중 하나만 있으면 그 값, 둘 다 있으면 평균), overall_pace_minmax, overtake_minmax, Instability_minmax_0_10
- 교란변수(컨디셔닝): Car_Score_Scaled_GP
- Y = rank_value (순위 높을수록 큰 값)
"""

import pandas as pd
import numpy as np
from pathlib import Path

try:
    import statsmodels.api as sm
    from statsmodels.stats.outliers_influence import variance_inflation_factor
except ImportError:
    sm = None
    variance_inflation_factor = None

BASE_DIR = Path(__file__).resolve().parent
FINAL_DIR = BASE_DIR / "final_data"
# beta.csv 기준 테이블 우선, 없으면 all, 없으면 기본
if (FINAL_DIR / "f1_merged_final_beta.csv").exists():
    MERGED_CSV = FINAL_DIR / "f1_merged_final_beta.csv"
elif (FINAL_DIR / "f1_merged_final_all.csv").exists():
    MERGED_CSV = FINAL_DIR / "f1_merged_final_all.csv"
else:
    MERGED_CSV = FINAL_DIR / "f1_merged_final.csv"


def minmax_0_10(series: pd.Series) -> pd.Series:
    """0~10 min-max 스케일링"""
    s = series.dropna()
    if len(s) == 0 or s.min() == s.max():
        return series
    return 10.0 * (series - s.min()) / (s.max() - s.min())


def build_gp_level_df() -> pd.DataFrame:
    """GP(레이스)·드라이버별 1행 데이터 로드 (이미 GP 단위면 그대로, 랩 단위면 집계)"""
    df = pd.read_csv(MERGED_CSV)
    if "rank_value" in df.columns and df.groupby(["Year", "Round", "EventName", "Driver"]).ngroups == len(df):
        # 구 CSV 호환: 실력지표 열 없으면 반전해서 생성
        if "Tyre_Management_minmax_0_10" not in df.columns and "Beta_tyre_minmax_0_10" in df.columns:
            df["Tyre_Management_minmax_0_10"] = 10.0 - df["Beta_tyre_minmax_0_10"]
        if "Stability_minmax_0_10" not in df.columns and "Instability_minmax_0_10" in df.columns:
            df["Stability_minmax_0_10"] = 10.0 - df["Instability_minmax_0_10"]
        if all(c in df.columns for c in PREDICTOR_COLS):
            return df
    agg_cols = {
        "FinalPosition": "first",
        "overall_pace_score": "first",
        "overtake_total_score": "first",
        "Instability_minmax_0_10": "mean",
        "Car_Score_Scaled_GP": "first",
    }
    for c in ["Beta_HARD_minmax_0_10", "Beta_MEDIUM_minmax_0_10", "Beta_SOFT_minmax_0_10"]:
        if c in df.columns:
            agg_cols[c] = "mean"
    gp = df.groupby(["Year", "Round", "EventName", "Driver"], as_index=False).agg(agg_cols)
    # 타이어 Beta 하나로: HARD/MEDIUM/SOFT 중 하나만 있으면 그 값, 여러 개 있으면 평균 (skipna=True)
    beta_cols = [c for c in ["Beta_HARD_minmax_0_10", "Beta_MEDIUM_minmax_0_10", "Beta_SOFT_minmax_0_10"] if c in gp.columns]
    gp["Beta_tyre_minmax_0_10"] = gp[beta_cols].mean(axis=1, skipna=True) if beta_cols else float("nan")
    # overall_pace_score, overtake_total_score minmax 0-10
    gp["overall_pace_score_minmax_0_10"] = minmax_0_10(gp["overall_pace_score"])
    gp["overtake_total_score_minmax_0_10"] = minmax_0_10(gp["overtake_total_score"])
    # Y: 순위가 높을수록(1등에 가까울수록) 높은 값 -> rank_value
    # 그랑프리별 최대 순위(참가 인원) 기준으로 변환
    gp["max_pos"] = gp.groupby(["Year", "Round"])["FinalPosition"].transform("max")
    gp["rank_value"] = gp["max_pos"] - gp["FinalPosition"] + 1  # 1등 = max_pos, 꼴찌 = 1
    gp = gp.drop(columns=["max_pos"])
    return gp


# 관심 설명변수(실력지표): Tyre Management, Stability = minmax 반전(10-x) so 높을수록 좋음
PREDICTOR_COLS = [
    "Tyre_Management_minmax_0_10",
    "overall_pace_score_minmax_0_10",
    "overtake_total_score_minmax_0_10",
    "Stability_minmax_0_10",
]
CONFOUNDER_COLS = ["Car_Score_Scaled_GP"]  # 차량 성능 교란 → 컨디셔닝


def run_regression(gp: pd.DataFrame):
    """다중회귀: Y ~ 관심변수 + 교란변수 (Car_Score_Scaled_GP로 컨디셔닝)"""
    y_col = "rank_value"
    X_cols = PREDICTOR_COLS + CONFOUNDER_COLS
    use = gp[[y_col] + X_cols].dropna(how="any")
    X = use[X_cols]
    y = use[y_col]
    X_const = sm.add_constant(X, has_constant="add")
    model = sm.OLS(y, X_const).fit()
    print(model.summary())
    return model


def run_regression_by_driver(gp: pd.DataFrame) -> pd.DataFrame:
    """드라이버별로 회귀 적합, 계수 + p-value + 설명력(R², Adj R²) + n_races 저장"""
    y_col = "rank_value"
    X_cols = PREDICTOR_COLS + CONFOUNDER_COLS
    all_cols = [y_col] + X_cols
    coef_names = ["const"] + X_cols
    rows = []
    for driver, grp in gp.groupby("Driver"):
        use = grp[all_cols].dropna(how="any")
        n_races = len(use)
        row = {"Driver": driver, "n_races": n_races}
        if n_races < len(X_cols) + 1:  # 최소 (파라미터 수 + 1) 필요
            for c in coef_names:
                row["coef_" + c] = np.nan
                row["pval_" + c] = np.nan
            row["rsquared"] = np.nan
            row["adj_rsquared"] = np.nan
            rows.append(row)
            continue
        try:
            X = use[X_cols]
            y = use[y_col]
            X_const = sm.add_constant(X, has_constant="add")
            model = sm.OLS(y, X_const).fit()
            for c in coef_names:
                row["coef_" + c] = model.params.get(c, np.nan)
                row["pval_" + c] = model.pvalues.get(c, np.nan)
            row["rsquared"] = model.rsquared
            row["adj_rsquared"] = model.rsquared_adj
            rows.append(row)
        except Exception:
            for c in coef_names:
                row["coef_" + c] = np.nan
                row["pval_" + c] = np.nan
            row["rsquared"] = np.nan
            row["adj_rsquared"] = np.nan
            rows.append(row)
    return pd.DataFrame(rows)


def check_multicollinearity(gp: pd.DataFrame):
    """다중공선성: VIF, 설명변수 상관행렬, Condition Number"""
    y_col = "rank_value"
    X_cols = PREDICTOR_COLS + CONFOUNDER_COLS
    use = gp[[y_col] + X_cols].dropna(how="any")
    X = use[X_cols]

    print("\n" + "=" * 60)
    print("다중공선성 검사 (Multicollinearity)")
    print("=" * 60)

    # 1) 설명변수 상관행렬
    print("\n[1] 설명변수 상관행렬 (Correlation Matrix)")
    print("-" * 60)
    corr = X.corr().round(4)
    print(corr.to_string())

    # 2) VIF (Variance Inflation Factor)
    # VIF > 5 또는 10 이면 다중공선성 우려
    if variance_inflation_factor is not None:
        X_const = sm.add_constant(X, has_constant="add")
        vif = pd.DataFrame(
            {
                "변수": X_const.columns,
                "VIF": [variance_inflation_factor(X_const.values, i) for i in range(X_const.shape[1])],
            }
        )
        vif = vif[vif["변수"] != "const"]  # const 제외
        print("\n[2] VIF (Variance Inflation Factor)")
        print("    (VIF > 5: 주의, VIF > 10: 다중공선성 우려)")
        print("-" * 60)
        print(vif.to_string(index=False))

    # 3) Condition Number (설계행렬 X)
    print("\n[3] Condition Number (설명변수 행렬 X)")
    print("-" * 60)
    X_centered = X - X.mean()
    sing = np.linalg.svd(X_centered, compute_uv=False)
    cond = sing[0] / sing[-1] if sing[-1] > 1e-10 else np.inf
    print(f"    Condition Number = {cond:.2f}")
    print("    (CN > 30: 다중공선성 가능성)")
    print("=" * 60)


def main():
    if not MERGED_CSV.exists():
        raise FileNotFoundError(f"병합 파일 없음: {MERGED_CSV}")
    if sm is None:
        raise ImportError("statsmodels 필요: pip install statsmodels")

    gp = build_gp_level_df()
    print(f"GP·드라이버 행 수: {len(gp):,}\n")
    all_cols = ["rank_value"] + PREDICTOR_COLS + CONFOUNDER_COLS
    use = gp[all_cols].dropna(how="any")
    print(f"회귀에 사용된 관측 수 (결측 제외): {len(use):,}\n")
    print("교란변수(컨디셔닝): Car_Score_Scaled_GP")
    print("=== 다중회귀 (Y = rank_value, Car_Score_Scaled_GP로 컨디셔닝) ===\n")
    model = run_regression(gp)
    check_multicollinearity(gp)
    summary_name = "regression_summary_beta.txt" if "beta" in str(MERGED_CSV) else "regression_summary.txt"
    summary_path = FINAL_DIR / summary_name
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"다중회귀 (Y = rank_value, Car_Score_Scaled_GP 교란변수 컨디셔닝)\n데이터: {MERGED_CSV.name}\n")
        f.write("=" * 60 + "\n\n")
        f.write(str(model.summary()))
    print(f"\n서머리 저장: {summary_path}")

    # 드라이버별 회귀 → 계수 + n_races 저장 (표본 적은 드라이버 제외용)
    driver_coefs = run_regression_by_driver(gp)
    coef_path = FINAL_DIR / "driver_regression_coefs.csv"
    driver_coefs.to_csv(coef_path, index=False)
    print(f"드라이버별 계수 저장: {coef_path}  (행={len(driver_coefs):,}, n_races 포함)")


if __name__ == "__main__":
    main()
